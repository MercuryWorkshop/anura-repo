type TorOptions = {
    torrc?: string;
    useSnowflake: boolean;
    wisp?: string;
};

declare class TorConnectionSocket {
    url: string;
    readyState: number;
    onopen: ((ev: Event) => void) | null;
    onmessage: ((ev: MessageEvent) => void) | null;
    onclose: ((ev: CloseEvent) => void) | null;
    onerror: ((ev: Event) => void) | null;
    private socket;
    private connected;
    private responseBuffer;
    static CONNECTING: number;
    static OPEN: number;
    static CLOSING: number;
    static CLOSED: number;
    CONNECTING: number;
    OPEN: number;
    CLOSING: number;
    CLOSED: number;
    binaryType: string;
    bufferedAmount: number;
    extensions: string;
    protocol: string;
    constructor(url: string, workerRef?: Worker);
    private handleReceive;
    private forwardData;
    send(data: string | ArrayBuffer | Uint8Array): void;
    close(): void;
    addEventListener(type: string, listener: any): void;
    removeEventListener(): void;
    dispatchEvent(): boolean;
}

type SnowstormInit = {
    torOptions: TorOptions;
    logFn: (msg: string) => void;
    errorFn: (msg: string) => void;
    bootstrapProgressFn: (progress: number, tag: string, summary: string) => void;
    torReadyFn: () => void;
};
declare function init(opts: SnowstormInit): void;

export { TorConnectionSocket, init };
export type { SnowstormInit };
