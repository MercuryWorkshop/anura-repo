/**
 * Minified by jsDelivr using Terser v5.3.5.
 * Original file: /npm/requestidlecallback-polyfill@1.0.2/index.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
window.requestIdleCallback=window.requestIdleCallback||function(e){var n=Date.now();return setTimeout((function(){e({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-n))}})}),1)},window.cancelIdleCallback=window.cancelIdleCallback||function(e){clearTimeout(e)};
//# sourceMappingURL=/sm/a3859b5eca0c66e4a62bb7809aeefbb71d233e45fc38e3bf9aebcd09dd1e0dc6.map