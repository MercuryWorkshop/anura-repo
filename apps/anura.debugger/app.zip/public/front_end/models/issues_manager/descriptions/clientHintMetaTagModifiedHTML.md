# Client Hint meta tag modified by javascript

Only delegate-ch meta tags in the original HTML sent from the server
are respected. Any injected via javascript (or other means) are ignored.
