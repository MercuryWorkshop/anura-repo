# getUserInfo() is disabled because FedCM is disabled.
