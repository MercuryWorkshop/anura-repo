# Ensure that the `Attribution-Reporting-Register-Trigger` header is valid

This page tried to register a trigger using the Attribution Reporting API but
failed because an `Attribution-Reporting-Register-Trigger` response header was
invalid.
