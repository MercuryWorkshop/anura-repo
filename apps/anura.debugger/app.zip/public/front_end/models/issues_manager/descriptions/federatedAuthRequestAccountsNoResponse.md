# The response body is empty when fetching the provider's accounts list.
