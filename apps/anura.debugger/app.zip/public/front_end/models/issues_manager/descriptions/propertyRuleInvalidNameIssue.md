# An @property rule was ignored

An @property rule is ignored because the property name is invalid.
