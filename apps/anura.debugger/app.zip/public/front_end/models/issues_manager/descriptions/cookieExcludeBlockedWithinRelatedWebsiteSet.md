# Third-party cookie blocked within the same Related Website Set

A cookie embedded by a site in the top-level page's Related Website Set was blocked
by third-party cookie blocking.
