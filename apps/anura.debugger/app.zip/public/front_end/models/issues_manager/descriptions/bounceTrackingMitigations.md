# Chrome may soon delete state for intermediate websites in a recent navigation chain

In a recent navigation chain, one or more websites accessed some form of local storage without prior user interaction. If these websites don't get such an interaction soon, Chrome will delete their state.
