# getUserInfo() caller is not an iframe.
