# Response was blocked by CORB (Cross-Origin Read Blocking)

Cross-Origin Read Blocking (CORB) blocked a cross-origin response.

