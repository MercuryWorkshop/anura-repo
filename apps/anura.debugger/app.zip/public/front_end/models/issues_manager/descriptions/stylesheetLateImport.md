# Define @import rules at the top of the stylesheet

An @import rule was ignored because it wasn't defined at the top of the stylesheet. Such rules must appear at the top,
before any style declaration and any other at-rule with the exception of @charset and @layer.
