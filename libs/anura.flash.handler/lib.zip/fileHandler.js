export function openFile(path) {
  let swfView = anura.wm.createGeneric("Flash Player");
  const ruffle = document.createElement("script")
  ruffle.src = import.meta.url.substring(0, import.meta.url.lastIndexOf("/")) + "/ruffle.js"
  swfView.content.append(ruffle);
  const flashContainer = document.createElement("div");
  flashContainer.setAttribute(
    "style",
    "top:0; left:0; bottom:0; right:0; width:100%; height:100%; border: none; margin: 0; padding: 0; background-color: #202124;"
  );
  anura.fs.readFile(path, function(err, data) {
    const flashObject = document.createElement("object");
    flashObject.setAttribute("data", URL.createObjectURL(new Blob([data])));
    flashObject.setAttribute("type", "application/x-shockwave-flash");
    flashObject.style.width = "100%";
    flashObject.style.height = "100%";
    flashContainer.appendChild(flashObject);
  });
  swfView.content.appendChild(flashContainer);
}

export function getIcon(path) {
  return import.meta.url.substring(0, import.meta.url.lastIndexOf("/")) + "/flash.svg";
}

export function getFileType(path) {
  return "Flash Animation";
}