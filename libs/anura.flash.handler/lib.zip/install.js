export default function install(anura) {
  anura.files.setModule("anura.flash.handler", "swf");
}
